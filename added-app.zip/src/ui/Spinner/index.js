export { default } from "./Spinner"
